package crud;

import java.util.List;

import org.springframework.stereotype.Component;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

@Component
public class DatabaseLogin {

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("dev");
	EntityManager manager = factory.createEntityManager();
	EntityTransaction transaction = manager.getTransaction();
	
	public void save(Movie movie) {
		transaction.begin();
		manager.persist(movie);
		transaction.commit();
	}

	public List<Movie> getMovies() {
		return manager.createNativeQuery("select * from Movie", Movie.class).getResultList();
	}
	

	 public Movie getMovie(int id) {
		return manager.find(Movie.class, id);
	}

	public void delete(int id) {
		Movie movie = getMovie(id);
		transaction.begin();
		manager.remove(getMovie(id));
		transaction.commit();
		
	}
	
	public void update(Movie movie) {
		transaction.begin();
		manager.merge(movie);
		transaction.commit();
	}
	
}
