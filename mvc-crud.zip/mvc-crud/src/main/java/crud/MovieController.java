package crud;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class MovieController {
	
	DatabaseLogin databaseLogin;
	
	public MovieController(DatabaseLogin databaseLogin) {
		this.databaseLogin = databaseLogin;
	}

	@GetMapping("/")
	public String loadMovie() {
		return "moviecrud.jsp";
	}
	
	@GetMapping("addmovie")
	public String addMovie() {
		return "addmovie.jsp";
	}
	
	@PostMapping("addmovie")
	public String addMovie(Movie movie, RedirectAttributes attributes) {
		databaseLogin.save(movie);
		attributes.addFlashAttribute("message","Data Saved Success");
		return "redirect:/";
	}
	
	@GetMapping("/viewmovie")
	public String viewMovie(ModelMap map, RedirectAttributes attributes) {
		List<Movie> movies = databaseLogin.getMovies();
		if(movies.isEmpty()) {
			attributes.addFlashAttribute("message"," No Data present");
			return "redirect:/";
		}
		map.put("movies", movies);
		return "viewmovie.jsp";
	}
	
	@GetMapping("/delete")
	public String delete(@RequestParam("id") int id, RedirectAttributes attributes) {
		databaseLogin.delete(id);
		attributes.addFlashAttribute("message", "Deleted Success");
		return "redirect:/viewmovie";
	}
	
	@GetMapping("/edit")
	public String edit(@RequestParam("id") int id, ModelMap map) {
		Movie movie = databaseLogin.getMovie(id);
		map.put("movie", movie);
		return "edit.jsp";
	}
	
	@PostMapping("/update-movie")
	public String updateMovie(Movie movie, RedirectAttributes attributes) {
		databaseLogin.update(movie);
		attributes.addFlashAttribute("message","Data Updated Success");
		return "redirect:/viewmovie";
	}
}
